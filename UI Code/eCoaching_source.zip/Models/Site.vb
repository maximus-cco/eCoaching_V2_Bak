﻿Public Class Site
    Public Property SiteID As String
    Public Property SiteName As String
    Public Property CSRs As List(Of Employee)
    Public Property Supervisors As List(Of Employee)
    Public Property Managers As List(Of Employee)
End Class
