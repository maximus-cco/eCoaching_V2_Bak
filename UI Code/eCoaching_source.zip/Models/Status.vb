﻿Public Class Status
    Public Property StatusID As String
    Public Property StatusText As String
End Class
