﻿Public Class Source
    Public Property SourceID As String
    Public Property SourceText As String
End Class
