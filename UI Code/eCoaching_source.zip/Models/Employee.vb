﻿Public Class Employee
    Public Property EmployeeID As String
    Public Property EmployeeName As String
End Class
