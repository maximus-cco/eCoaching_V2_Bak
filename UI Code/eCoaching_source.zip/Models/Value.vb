﻿Public Class Value
    Public Property ValueID As String
    Public Property ValueText As String
End Class
