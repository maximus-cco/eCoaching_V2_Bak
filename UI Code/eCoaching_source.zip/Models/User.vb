﻿Public Class User
    Public Property LanID As String
    Public Property Name As String
    Public Property JobCode As String
    Public Property Email As String
End Class
